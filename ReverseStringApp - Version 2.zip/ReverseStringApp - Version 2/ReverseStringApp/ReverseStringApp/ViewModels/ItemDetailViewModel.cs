﻿using System;
using System.Threading.Tasks;
using ReverseStringApp.Models;
using Xamarin.Forms;
using ReverseStringApp.Helpers;

namespace ReverseStringApp.ViewModels
{
    public class ItemDetailViewModel : BaseViewModel
    {
        public Item Item { get; set; }
        public Command<string> ReverseTextCommand { get; set; }
        public ItemDetailViewModel(Item item = null)
        {
            Title = item.Text;
            Item = item;
            if (item.Text.ToLower().Trim().Contains(Constants.ConditionTextForMenu.ToLower().Trim()))
            {
                ReverseTextCommand = new Command<string>(async (string textToReverse) => await ExecuteReverseTextByCharacterCommand(textToReverse));
            }
            else
            {
                ReverseTextCommand = new Command<string>(async (string textToReverse) => await ExecuteReverseTextByCaseCommand(textToReverse));
            }
            
        }

        private Task ExecuteReverseTextByCharacterCommand(string ToBeReverse)
        {
            string reverSestring = "";
            var Length = ToBeReverse.Length - 1;
            while (Length >= 0)
            {
                reverSestring = reverSestring + ToBeReverse[Length];
                Length--;
            }
            Reversestring = reverSestring;
            return Task.FromResult(true);
        }

        private Task ExecuteReverseTextByCaseCommand(string ToBeReverse)
        {
            string reverSestring = "";
            for (int i = 0, len = ToBeReverse.Length; i < len; i++)
            {
                var character = ToBeReverse[i];
                if ( char.IsLower(character) )
                {
                    // The character is lowercase
                    reverSestring = reverSestring + char  .ToUpper (character);
                }
                else
                {
                    // The character is uppercase
                    reverSestring = reverSestring + char .ToLower (character);
                }
            }
            Reversestring = reverSestring;
            return Task.FromResult(true);
        }

        string reversestring = string.Empty;
        public string Reversestring
        {
            get { return reversestring; }
            set { SetProperty(ref reversestring, value); }
        }

        int quantity = 1;
        public int Quantity
        {
            get { return quantity; }
            set { SetProperty(ref quantity, value); }
        }
        
    }
}