﻿using System;
using System.Windows.Input;
using Xamarin.Forms;

namespace ReverseStringApp.ViewModels
{
    public class AboutViewModel : BaseViewModel
    {
        public AboutViewModel()
        {
            Title = "Find more on GitHub";

            OpenWebCommand = new Command(() => Device.OpenUri(new Uri("https://github.com/sanketjo")));
        }

        /// <summary>
        /// Command to open browser to xamarin.com
        /// </summary>
        public ICommand OpenWebCommand { get; }
    }
}
