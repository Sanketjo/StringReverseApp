﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace ReverseStringApp.Helpers
{
    public static class Constants
    {
        public const string ENTER_TEXT = "Enter Some Text to Reverse...";//Entry PlaceHolder text for input text to be reversed
        public const string REVERSE_STRING_TEXT = "Reversestring";//Binding for reverse Case string
        public const string MENU_ICON = "hamburgar.png";//"menue_hamburger.png";

        public const string ConditionTextForMenu= "Reverse By Character Order";
    }
}
