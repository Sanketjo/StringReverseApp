﻿
using Xamarin.Forms;

namespace ReverseStringApp.Views
{
    public partial class AboutPage : ContentPage
    {
        public AboutPage()
        {
            InitializeComponent();
        }
    }
}
