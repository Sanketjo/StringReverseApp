﻿
using ReverseStringApp.Helpers;
using ReverseStringApp.ViewModels;
using System;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace ReverseStringApp.Views
{
    public partial class ItemDetailPage : ContentPage
    {
        ItemDetailViewModel viewModel;

        // Note - The Xamarin.Forms Previewer requires a default, parameterless constructor to render a page.
        public ItemDetailPage()
        {
            InitializeComponent();
        }

        public ItemDetailPage(ItemDetailViewModel viewModel)
        {
            InitializeComponent();

            BindingContext = this.viewModel = viewModel;
            nameLabel.Text = Helpers.Constants.ENTER_TEXT;

        }

        private async void RiverseButtonClicked(object sender, System.EventArgs e)
        {

            try
            {
                if (!string.IsNullOrEmpty(descriptionTextEnteryText.Text?.Trim()))
                {
                    if (this.viewModel.ReverseTextCommand.CanExecute(descriptionTextEnteryText.Text))
                    {
                        this.viewModel.ReverseTextCommand.Execute(descriptionTextEnteryText.Text);
                        reverseStringLabel.SetBinding(Label.TextProperty, Constants.REVERSE_STRING_TEXT);
                    };
                }

                else
                {
                    await DisplayAlert("Opss !!!", "Enter Something to Reverse", "Ok", "cancel");
                    descriptionTextEnteryText.BackgroundColor = Color.Red;
                    await Task.Delay(100);
                    descriptionTextEnteryText.BackgroundColor = Color.White;
                }
            }
            catch (Exception ex)
            {

            }

        }
    }
}
