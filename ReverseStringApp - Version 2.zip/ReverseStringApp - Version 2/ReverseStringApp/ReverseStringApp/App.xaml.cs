﻿using ReverseStringApp.Helpers;
using ReverseStringApp.Views;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

[assembly: XamlCompilation(XamlCompilationOptions.Compile)]
namespace ReverseStringApp
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();

            SetMainPage();
        }

        public static void SetMainPage()
        {
            Current.MainPage = new TabbedPage
            {

                Children =
                {
                    new NavigationPage(new MasterPage()) {Title="Reverse String",Icon = "tab_about.png"  }
                    ,
                    new NavigationPage(new AboutPage()) {Title="Web View Example",Icon = Device.OnPlatform("tab_about.png",null,null) }
                 }
            };



        }
        class MasterPage : MasterDetailPage
        {

            public MasterPage() : base()
            {
                var items = new ItemsPage();
                Title = "Reverse String";
                Master = items;
                NavigationPage.SetHasNavigationBar(this, false);
                Detail = new AboutPage();

            }
        }
    }
}
